import React from "react";
import { Link } from "react-router-dom";

const Homepage = () => {
  return <div />;
};

export default Homepage;
